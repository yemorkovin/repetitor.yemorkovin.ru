

<?php $__env->startSection('content'); ?>

<div style="width: 600px; margin: 20px auto; min-height: 320px;">
    <hr />
    <a href="<?php echo e(url('admin')); ?>">Назад</a>
    <h2 align="center">Статистика на сайте</h2>
    <p><b>Общее количество посещений <?php echo e($stats->count()); ?></b></p>
    <p><b><a href="/stat_clear">Очистить статистику</a></b></p>
    <table width="100%" align="center" cellpadding="0" cellspacing="0" border="1">
        <tr>
            <td>Страна</td>
            <td>Регион</td>
            <td>Город</td>
            <td>Дата</td>
        </tr>
        <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($stat->country); ?></td>
            <td><?php echo e($stat->regionName); ?></td>
            <td><?php echo e($stat->city); ?></td>
            <td><?php echo e($stat->date); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\rep.loc\resources\views/statistic.blade.php ENDPATH**/ ?>