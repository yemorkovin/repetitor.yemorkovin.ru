

<?php $__env->startSection('content'); ?>
<style type="text/css">
    input{
        color: black !important;
    }
</style>
<div style="width: 70%; margin: 20px auto; min-height: 320px;">
    <hr />
    <a href="<?php echo e(url('admin')); ?>">Назад</a>
    <h2>Об авторе</h2>
    <form action="about" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($about->id); ?>">
        <div>
            Заголовок
        </div>
        <div>
           <input type="text" name="header" value="<?php echo e($about->header); ?>" />
        </div>
        <div>
            Текст
        </div>
        <div>
           <textarea cols="50" rows="20" name="txt"><?php echo e($about->txt); ?></textarea>
        </div>
        <div>
            Фото
        </div>
        <div>
            <img src="public/images/<?php echo e($about->img); ?>" id="img" width="300px" alt="пока нет фото">
            <input type="file" id="file-upload" name="img">
        </div>
        
        <div>
            <input type="submit" value="Обновить">
        </div>
    </form>
    <hr />
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\rep.loc\resources\views/about.blade.php ENDPATH**/ ?>