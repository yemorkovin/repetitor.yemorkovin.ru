

<?php $__env->startSection('content'); ?>
<style type="text/css">
    input{
        color: black !important;
    }
</style>
<div style="width: 400px; margin: 20px auto; min-height: 320px;">
    <hr />
    <a href="/courses">Назад</a>
    <form action="" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($course->id); ?>">
        <div>
            Заголовок
        </div>
        <div>
            <input type="text" value="<?php echo e($course->title); ?>" name="title">
        </div>

        <div>
            Описание
        </div>
        <div>
            <textarea cols="45" rows="10" name="description"><?php echo e($course->description); ?></textarea>
        </div>
         <div>
            Полный текст
        </div>
        <div>
            <textarea cols="45" rows="10" name="full_text"><?php echo e($course->full_text); ?></textarea>        
        </div>
        <div>
            Картинка
        </div>
        <div>
            <img src="/public/images/<?php echo e($course->img); ?>" id="img" width="300px">
            <input type="file" id="file-upload" name="img">
        </div>
        <div>
            <input type="submit" value="Обновить">
        </div>
    </form>
    <hr />
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\rep.loc\resources\views/editcourses.blade.php ENDPATH**/ ?>