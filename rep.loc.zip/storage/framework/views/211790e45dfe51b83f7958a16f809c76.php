

<?php $__env->startSection('content'); ?>

<div style="width: 400px; margin: 20px auto; min-height: 320px;">
    <form action="<?php echo e(route('login')); ?>" method="post">
        <?php echo csrf_field(); ?>
        Email: <input type="email" name="email" style="color: #000"/>
        Password: <input type="password" name="password" style="color: #000">
        <input type="submit" name="sub" value="Авторизация">
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\rep.loc\resources\views/login.blade.php ENDPATH**/ ?>