

<?php $__env->startSection('content'); ?>
<style type="text/css">
    input{
        color: black !important;
    }
</style>
<div style="width: 400px; margin: 20px auto; min-height: 320px;">
    <hr />
    <a href="/admin">Назад</a>
        
        <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($price->id); ?>">
        <div>
            <input type="text"  name="title" value="<?php echo e($price->title); ?>">
        </div>
        <div>
            <input type="number"  name="price" value="<?php echo e($price->price); ?>">
        </div>
        <div>
            <input type="submit" value="Обновить">
        </div>
        </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <hr />
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\rep.loc\resources\views/editprice.blade.php ENDPATH**/ ?>