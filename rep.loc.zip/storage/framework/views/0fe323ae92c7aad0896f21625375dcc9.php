

<?php $__env->startSection('content'); ?>

<div style="width: 700px; margin: 20px auto; min-height: 320px;">
    <hr />
    <p><a href="<?php echo e(url('admin')); ?>">Назад</a></p>
    <ul>
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="editslider/<?php echo e($slider->id); ?>"><?php echo e($slider->description); ?></a> <span ><a href="editslider/delete/<?php echo e($slider->id); ?>" style="color:red">Удалить</a></span></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <hr />
    <p><a href="/editslider/add">ДОБАВИТЬ СЛАЙДЕР</a></p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\rep.loc\resources\views/listslider.blade.php ENDPATH**/ ?>