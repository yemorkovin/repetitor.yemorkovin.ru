

<?php $__env->startSection('content'); ?>
<div class="slider_area" id="main">
        <div class="slider_active owl-carousel">
            
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="single_slider  d-flex align-items-center slider_bg_1" style="background-image: url(/public/images/<?php echo e($d->img); ?>);">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="slider_text ">
                                <h3>
                                    <?php echo $d->description; ?>

                                    </h3>
                                    <div style="overflow:hidden;font-size: 24px;color:red;display:block;position: relative;">
                                        <?php if($d->text_free): ?>
                                        <?php echo e($d->text_free); ?>

                                        <?php endif; ?>
                                        
                                    <div style="box-shadow: 0px 0px 15px white;animation-iteration-count: infinite;animation-name: slidein;animation-duration: 3s;width: 5px;height: 50px;background: #fff;position:absolute;top:-10px;transform: rotate(20deg);"></div>
                                    </div><br />
                                    <style>
                                        @keyframes slidein {
                                          from {
                                            left: 0px;
                                          }
                                        
                                          to {
                                            left:300px;
                                          }
                                        }
                                    </style>
                                    <?php if($d->button): ?>
<a href="<?php echo e($d->button); ?>" class="boxed-btn3"><?php echo e($d->text_button); ?></a>
                                    <?php endif; ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

     <div class="event_details_area section__padding" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="single_event d-flex align-items-center">
                        <div class="thumb" >
                            <img src="/public/images/<?php echo e($about->img); ?>" alt="">
                            
                        </div>
                        <div class="event_details_info">
                            <div class="event_info">
                                <a href="#">
                                    <h4><?php echo e($about->header); ?></h4>
                                 </a>
                            </div>
                            <?php echo $about->txt; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="popular_program_area section__padding" id="courses">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section_title text-center">
                        <h3>Популярные курсы</h3>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <nav class="custom_tabs text-center">
                        <div class="nav" id="nav-tab" role="tablist">
                            <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true">WEB                                </a>
                        </div>
                    </nav>
                </div>
            </div>
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                    <div class="row">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="single__program">
                                <div class="program_thumb">
                                    <img src="/public/images/<?php echo e($course->img); ?>" alt="<?php echo e($course->title); ?>">
                                </div>
                                <div class="program__content">
                                    <h4><?php echo e($course->title); ?></h4>
                                    <?php echo $course->description; ?>

                                    <a href="/courses/view/<?php echo e($course->id); ?>" class="boxed-btn5">Подробнее</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                </div>
            </div>
            
        </div>
    </div>
    <div class="service_area gray_bg" id="prices">
        <div class="container">
            <div class="row justify-content-center ">
                <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6">
                    <div class="single_service d-flex align-items-center ">
                       
                        <div class="service_info">
                            <h4><?php echo e($price->title); ?></h4><br />
                            <p><?php echo e($price->price); ?> руб./час</p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        </div>
    </div>
    <div class="recent_event_area section__padding" id="otzivi">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8 col-md-10">
                    <div class="section_title text-center mb-70">
                        <h3 class="mb-45">Отзывы</h3>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-10">

                    <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="single_event d-flex align-items-center">
                        <div class="date text-center">
                            <span><?php echo e($review->date_1); ?></span>
                            <p><?php echo e($review->date_2); ?><br /><?php echo e($review->date_3); ?></p>
                        </div>
                        <div class="event_info">
                            <a href="event_details.html">
                                <h4><?php echo e($review->title); ?></h4>
                             </a>
                            <p><span> <?php echo e($review->name); ?> </p>
                                <p><a href="<?php echo e($review->link); ?>"> <?php echo e($review->link); ?></a> </p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                     
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\rep.loc\resources\views/index.blade.php ENDPATH**/ ?>