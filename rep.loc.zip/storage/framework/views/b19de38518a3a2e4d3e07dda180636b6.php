

<?php $__env->startSection('content'); ?>
<style type="text/css">
    input{
        color: black !important;
    }
</style>
<div style="width: 400px; margin: 20px auto; min-height: 320px;">
    <hr />
    <a href="/courses">Назад</a>
    <form action="" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div>
            Заголовок
        </div>
        <div>
            <input type="text"  name="title">
        </div>

        <div>
            Описание
        </div>
        <div>
            <textarea cols="45" rows="10" name="description"></textarea>
        </div>
         <div>
            Полный текст
        </div>
        <div>
            <textarea cols="45" rows="10" name="full_text"></textarea>        
        </div>
        <div>
            Картинка
        </div>
        <div>
            <img src="" id="img" width="300px">
            <input type="file" id="file-upload" name="img">
        </div>
        <div>
            <input type="submit" value="Добавить">
        </div>
    </form>
    <hr />
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\rep.loc\resources\views/addcourses.blade.php ENDPATH**/ ?>