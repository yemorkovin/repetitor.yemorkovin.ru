

<?php $__env->startSection('content'); ?>
<style type="text/css">
    input{
        color: black !important;
    }
</style>
<div style="width: 400px; margin: 20px auto; min-height: 320px;">
    <hr />
    <a href="<?php echo e(url('editslider')); ?>">Назад</a>
    <h2>Добавить слайдер</h2>
    <form action="add" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id">
        <div>
            Описание
        </div>
        <div>
            <input type="text" name="description">
        </div>

        <div>
            Текст светащий
        </div>
        <div>
            <input type="text" name="text_free">
        </div>
        <div>
            Фон
        </div>
        <div>
            <span>6912x3456</span>
            <img src="#" id="img" width="300px" alt="пока нет фото">
            <input type="file" id="file-upload" name="img">
        </div>
        <div>
            Кнопка
        </div>
        <div>
            <input type="text" name="button">
        </div>
        <div>
            Текст кнопки
        </div>
        <div>
            <input type="text" name="text_button">
        </div>
        <div>
            <input type="submit" value="Обновить">
        </div>
    </form>
    <hr />
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\rep.loc\resources\views/addslider.blade.php ENDPATH**/ ?>