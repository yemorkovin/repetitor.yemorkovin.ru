

<?php $__env->startSection('content'); ?>

        <div style="width: 90%; margin: 10px auto">
                <img src="/public/images/<?php echo e($course->img); ?>" width="100%" alt="" style="text-align: center">
                    <h4><?php echo e($course->title); ?></h4>
                    <div>
                        <?php echo $course->full_text; ?>

                    </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\rep.loc\resources\views/coursesview.blade.php ENDPATH**/ ?>