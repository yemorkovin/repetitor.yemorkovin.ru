

<?php $__env->startSection('content'); ?>
<style type="text/css">
    input{
        color: black !important;
    }
</style>
<div style="width: 400px; margin: 20px auto; min-height: 320px;">
    <hr />
    <a href="<?php echo e(url('admin')); ?>">Назад</a>
    <h2>Добавить рассписание</h2>
    <form action="" method="post">
        <?php echo csrf_field(); ?>
        <div>
            Заголовок
        </div>
        <div>
            <input type="text" name="title">
        </div>

        <div>
            Дата и время
        </div>
        <div>
            <input type="datetime-local" name="start">
        </div>
        <div>
            <input type="submit" value="Добавить">
        </div>
    </form>
    <hr />
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\rep.loc\resources\views/addcalendar.blade.php ENDPATH**/ ?>