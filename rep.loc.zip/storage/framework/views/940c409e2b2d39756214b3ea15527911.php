

<?php $__env->startSection('content'); ?>
<style type="text/css">
    input{
        color: black !important;
    }
</style>
<div style="width: 400px; margin: 20px auto; min-height: 320px;">
    <hr />
    <a href="<?php echo e(url('editslider')); ?>">Назад</a>
    <form action="<?php echo e(route('editslider')); ?>" method="post" enctype="multipart/form-data">
        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($sl->id); ?>">
        <div>
            Описание
        </div>
        <div>
            <input type="text" value="<?php echo e($sl->description); ?>" name="description">
        </div>

        <div>
            Текст светащий
        </div>
        <div>
            <input type="text" value="<?php echo e($sl->text_free); ?>" name="text_free">
        </div>
        <div>
            Фон
        </div>
        <div>
            <span>6912x3456</span>
            <img src="/images/<?php echo e($sl->img); ?>" id="img" width="300px">
            <input type="file" id="file-upload" name="img">
        </div>
        <div>
            Кнопка
        </div>
        <div>
            <input type="text" value="<?php echo e($sl->button); ?>" name="button">
        </div>
        <div>
            Текст кнопки
        </div>
        <div>
            <input type="text" value="<?php echo e($sl->text_button); ?>" name="text_button">
        </div>
        <div>
            <input type="submit" value="Обновить">
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </form>
    <hr />
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\rep.loc\resources\views/editoneslider.blade.php ENDPATH**/ ?>